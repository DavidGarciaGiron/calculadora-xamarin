Basic Calculator (Xamarin.Forms)
===========================

This Xamarin.Forms app provides a simple calculator you can use on your Android or iOS device

Follow the [setup instructions](https://developer.xamarin.com/guides/cross-platform/live/install) to try this out on your iPhone.

![](Screenshots/basic-calculator-sml.png)

[xamarin.com/live](https://xamarin.com/live)
